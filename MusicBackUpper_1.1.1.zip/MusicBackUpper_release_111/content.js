// content.js v12

const LOG = (...args) => console.log("[MusicBackUpper]", ...args);

let currentVideoId = null;
let listenTimer = null;
let pauseRetryTimer = null;
let hasRecorded = false;
let watchStartTime = null; // このセッションで視聴開始した時刻

function init() {
  observeUrlChange();
  setTimeout(checkCurrentVideo, 1000);
  setupVisibilityChange();
  setupVideoEvents();
}

// ── URL変化の監視 ─────────────────────────────────────────

function observeUrlChange() {
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      LOG("URL変化:", url);
      // 即時チェック + 少し遅れてもチェック（DOMの更新を待つ）
      checkCurrentVideo();
      setTimeout(checkCurrentVideo, 1000);
    }
  }).observe(document, { subtree: true, childList: true });
}

function checkCurrentVideo() {
  const url = new URL(location.href);
  const videoId = url.searchParams.get("v");
  if (!videoId) return;
  if (videoId === currentVideoId) return;
  LOG("新しい動画:", videoId);
  // currentVideoIdを先に更新することで、進行中のwaitForTitleが中止される
  currentVideoId = videoId;
  resetSession();
  // タイトルがまだ前の曲のものの可能性があるので少し待ってから取得
  setTimeout(() => {
    // 再度確認（複数回呼ばれた場合の整合性チェック）
    const nowId = new URL(location.href).searchParams.get("v");
    if (nowId === videoId) waitForTitle(videoId);
  }, 300);
}

// ── セッションリセット ────────────────────────────────────

function resetSession() {
  hasRecorded = false;
  watchStartTime = null;
  clearTimeout(listenTimer);
  clearTimeout(pauseRetryTimer);
  if (titleObserver) {
    titleObserver.disconnect();
    titleObserver = null;
  }
  observingForVideoId = null;
}

// ── タイトル・チャンネル取得 ──────────────────────────────

function getTitle() {
  // document.titleはYouTubeがナビゲーション時に素早く更新するので最優先
  const pageTitle = document.title;
  if (pageTitle && pageTitle !== "YouTube" && pageTitle.includes(" - YouTube")) {
    return pageTitle.replace(/ - YouTube$/, "").trim();
  }

  // フォールバック：DOMセレクタ
  const selectors = [
    "h1.ytd-watch-metadata yt-formatted-string",
    "ytd-watch-metadata h1 yt-formatted-string",
    "#above-the-fold h1 yt-formatted-string",
    "h1.style-scope.ytd-watch-metadata",
    "#title h1",
    "h1.title",
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el && el.textContent.trim()) return el.textContent.trim();
  }

  // 最終フォールバック
  if (pageTitle && pageTitle !== "YouTube") {
    return pageTitle.replace(/ - YouTube$/, "").trim();
  }
  return null;
}

function getChannelName() {
  const selectors = [
    "ytd-video-owner-renderer #channel-name a",
    "#owner #channel-name a",
    "#channel-name a",
    "ytd-channel-name a",
    "#owner-name a",
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el && el.textContent.trim()) return el.textContent.trim();
  }
  return "";
}

// ── タイトル監視（MutationObserverベース） ───────────────────

let titleObserver = null;
let observingForVideoId = null;

function startTitleObserver(videoId) {
  if (titleObserver) {
    titleObserver.disconnect();
    titleObserver = null;
  }
  observingForVideoId = videoId;

  const titleEl = document.querySelector("title");
  if (!titleEl) {
    setTimeout(() => {
      if (observingForVideoId === videoId) startTitleObserver(videoId);
    }, 300);
    return;
  }

  // YouTubeのページ遷移では必ず一度 "YouTube" になってから新タイトルに変わる
  // その変化をObserverで待つ（即時取得はしない）
  let seenYouTube = document.title === "YouTube" || !document.title.includes(" - YouTube");

  titleObserver = new MutationObserver(() => {
    if (observingForVideoId !== videoId) {
      titleObserver.disconnect();
      return;
    }
    const nowId = new URL(location.href).searchParams.get("v");
    if (nowId !== videoId) {
      LOG(`title変化 - URL不一致で無視 (監視: ${videoId}, 現在: ${nowId})`);
      return;
    }

    const raw = document.title;

    // "YouTube" の状態を一度通過したフラグを立てる
    if (!raw || raw === "YouTube" || !raw.includes(" - YouTube")) {
      seenYouTube = true;
      return;
    }

    // "YouTube" を経由していない場合（前の曲のタイトルがそのまま残っている状態）は無視
    if (!seenYouTube) {
      LOG(`title変化 - YouTube経由なし、前の曲の可能性があるため無視: "${raw}"`);
      return;
    }

    const title = raw.replace(/ - YouTube$/, "").trim();
    if (!title || title === "YouTube") return;

    LOG(`タイトル確定: "${title}" (videoId: ${videoId})`);
    titleObserver.disconnect();
    titleObserver = null;
    observingForVideoId = null;
    scheduleRecord(videoId, title);
  });

  titleObserver.observe(titleEl, { childList: true, characterData: true, subtree: true });
  LOG(`タイトル監視開始 (videoId: ${videoId}, seenYouTube: ${seenYouTube})`);

  // タイムアウト
  setTimeout(() => {
    if (observingForVideoId !== videoId) return;
    const nowId = new URL(location.href).searchParams.get("v");
    if (nowId !== videoId) return;
    const fallback = document.title.replace(/ - YouTube$/, "").trim();
    if (fallback && fallback !== "YouTube") {
      LOG(`タイムアウトフォールバック: "${fallback}"`);
      if (titleObserver) { titleObserver.disconnect(); titleObserver = null; }
      observingForVideoId = null;
      scheduleRecord(videoId, fallback);
    }
  }, 15000);
}

function waitForTitle(videoId) {
  startTitleObserver(videoId);
}

// ── 30秒タイマー ─────────────────────────────────────────

function scheduleRecord(videoId, title) {
  if (hasRecorded) return;
  clearTimeout(listenTimer);
  clearTimeout(pauseRetryTimer);
  watchStartTime = Date.now();
  LOG(`30秒タイマー開始: "${title}"`);
  listenTimer = setTimeout(() => tryRecord(videoId, title, 0), 30000);
}

// ── 記録実行 ─────────────────────────────────────────────

function tryRecord(videoId, title, retries) {
  if (hasRecorded) return;

  const currentId = new URL(location.href).searchParams.get("v");
  if (currentId !== videoId) {
    LOG("動画が変わったため中止");
    return;
  }

  // バックグラウンドでも再生中なら記録する
  // ただし動画が一時停止中は待機（別タブで止まっているケースの除外）
  const video = document.querySelector("video");
  if (!video || video.paused) {
    LOG(`一時停止中のため待機 (${retries + 1}回目)`);
    if (retries < 30) {
      pauseRetryTimer = setTimeout(() => tryRecord(videoId, title, retries + 1), 5000);
    }
    return;
  }

  hasRecorded = true;
  const channelName = getChannelName();
  LOG(`記録送信: "${title}" / ch: "${channelName}"`);

  chrome.runtime.sendMessage({
    type: "CHECK_AND_RECORD",
    payload: {
      videoId, title, channelName,
      url: `https://www.youtube.com/watch?v=${videoId}`,
      timestamp: new Date().toISOString(),
    },
  }, () => {
    if (chrome.runtime.lastError) {
      LOG("送信エラー:", chrome.runtime.lastError.message);
    }
  });
}

// ── 可視性変化（別タブ切り替え） ─────────────────────────

function setupVisibilityChange() {
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      // フォアグラウンドに戻ったとき、まだ未記録なら監視を再開
      if (!hasRecorded && currentVideoId) {
        LOG("フォアグラウンド復帰: タイトル監視再開");
        startTitleObserver(currentVideoId);
      }
    }
  });
}

// ── 動画プレイヤーイベント（再生ボタン押下検知） ──────────

function setupVideoEvents() {
  // videoタグが生成されるのを待ってからイベントを設定
  waitForVideo();
}

function waitForVideo(attempts = 0) {
  if (attempts > 20) return;
  const video = document.querySelector("video");
  if (video) {
    attachVideoEvents(video);
  } else {
    setTimeout(() => waitForVideo(attempts + 1), 500);
  }
}

function attachVideoEvents(video) {
  // 再生開始イベント：一時停止から再開した場合もここが呼ばれる
  video.addEventListener("play", () => {
    const videoId = new URL(location.href).searchParams.get("v");
    if (!videoId) return;

    if (videoId !== currentVideoId) {
      // 動画IDが変わっていた場合は新規扱い
      currentVideoId = videoId;
      resetSession();
      waitForTitle(videoId);
      return;
    }

    // 同じ動画で再生が再開された場合
    if (!hasRecorded) {
      // タイマーが止まっていたら監視再開
      if (!listenTimer && !titleObserver) {
        LOG("再生再開: タイトル監視再開");
        startTitleObserver(videoId);
      }
    } else {
      const now = Date.now();
      if (!watchStartTime || (now - watchStartTime) > 1 * 60 * 1000) {
        LOG("再生再開（新セッション）");
        hasRecorded = false;
        watchStartTime = null;
        startTitleObserver(videoId);
      }
    }
  });

  // 動画が変わったときにvideoタグも入れ替わる場合があるので監視
  video.addEventListener("emptied", () => {
    setTimeout(() => {
      const newVideo = document.querySelector("video");
      if (newVideo && newVideo !== video) {
        LOG("videoタグ入れ替わり検知");
        attachVideoEvents(newVideo);
      }
    }, 500);
  });
}

init();

// ── クイズモード：タイトル等を隠す ───────────────────────────

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "QUIZ_MODE_START") {
    enableQuizMode(message.clipSec || 3);
  }
});

function enableQuizMode(clipSec) {
  // すでに適用済みならスキップ
  if (document.getElementById("mbu-quiz-style")) return;

  const style = document.createElement("style");
  style.id = "mbu-quiz-style";
  style.textContent = `
    /* タイトル・チャンネル名・サムネ・概要・関連動画を隠す */
    #title h1,
    h1.ytd-watch-metadata,
    ytd-watch-metadata h1,
    #channel-name,
    #owner,
    ytd-video-owner-renderer,
    #description,
    ytd-expander,
    ytd-watch-next-secondary-results-renderer,
    #related,
    ytd-compact-video-renderer,
    .ytp-title,
    .ytp-title-text,
    .ytp-chrome-top,
    #info-contents,
    ytd-sentiment-bar-renderer,
    #super-title,
    ytd-subscribe-button-renderer {
      visibility: hidden !important;
      opacity: 0 !important;
    }
    /* クイズバナーを表示 */
    #mbu-quiz-banner {
      position: fixed;
      top: 0; left: 0; right: 0;
      background: linear-gradient(135deg, #7c3aed, #c026d3);
      color: #fff;
      text-align: center;
      padding: 10px;
      font-size: 15px;
      font-weight: 700;
      z-index: 99999;
      font-family: 'Segoe UI', sans-serif;
    }
  `;
  document.head.appendChild(style);

  // バナー追加
  const banner = document.createElement("div");
  banner.id = "mbu-quiz-banner";
  banner.textContent = `🎵 MusicBackUpper クイズモード　このタブは${clipSec}秒後に自動で閉じます`;
  document.body.prepend(banner);
}
