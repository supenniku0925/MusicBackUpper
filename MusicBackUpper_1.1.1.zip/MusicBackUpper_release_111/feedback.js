// feedback.js

const WEBHOOK_URL = "https://discord.com/api/webhooks/1503333381424021524/j2oebhDJvA0PebAS_KBuguPsZfckChGmpnp5F46vr8-a-C2qvj6O1Kzyaqhids32wHpJ";

// バージョン自動取得
const version = chrome.runtime.getManifest().version;
document.getElementById("version").value = `v${version}`;

// 文字数カウント
const messageEl = document.getElementById("message");
const charCountEl = document.getElementById("charCount");
messageEl.addEventListener("input", () => {
  charCountEl.textContent = messageEl.value.length;
});

// 送信
document.getElementById("btnSend").addEventListener("click", async () => {
  const category = document.getElementById("category").value;
  const message = messageEl.value.trim();

  if (!message) {
    messageEl.focus();
    messageEl.style.borderColor = "#f87171";
    setTimeout(() => messageEl.style.borderColor = "", 2000);
    return;
  }

  const btn = document.getElementById("btnSend");
  btn.disabled = true;
  btn.textContent = "送信中...";

  const now = new Date();
  const timestamp = `${now.getFullYear()}/${String(now.getMonth()+1).padStart(2,"0")}/${String(now.getDate()).padStart(2,"0")} ${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;

  const payload = {
    embeds: [{
      title: `📬 お便りが届きました`,
      color: 0x7c3aed,
      fields: [
        { name: "カテゴリ", value: category, inline: true },
        { name: "バージョン", value: `v${version}`, inline: true },
        { name: "送信日時", value: timestamp, inline: true },
        { name: "メッセージ", value: message },
      ],
      footer: { text: "MusicBackUpper フィードバック" },
    }]
  };

  try {
    const res = await fetch(WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const formEl = document.getElementById("form");
    const resultEl = document.getElementById("result");

    if (res.ok) {
      formEl.style.display = "none";
      resultEl.style.display = "block";
      resultEl.className = "result success";
      document.getElementById("resultIcon").textContent = "✅";
      document.getElementById("resultTitle").textContent = "送信しました！";
      document.getElementById("resultMsg").textContent = "お便りありがとうございます。開発の参考にさせていただきます。";
    } else {
      throw new Error(`HTTP ${res.status}`);
    }
  } catch (e) {
    const formEl = document.getElementById("form");
    const resultEl = document.getElementById("result");
    formEl.style.display = "none";
    resultEl.style.display = "block";
    resultEl.className = "result error";
    document.getElementById("resultIcon").textContent = "❌";
    document.getElementById("resultTitle").textContent = "送信に失敗しました";
    document.getElementById("resultMsg").textContent = "ネットワークエラーが発生しました。時間をおいて再度お試しください。";
  }
});

// 戻るボタン
document.getElementById("btnBack").addEventListener("click", () => {
  document.getElementById("form").style.display = "block";
  document.getElementById("result").style.display = "none";
  document.getElementById("message").value = "";
  charCountEl.textContent = "0";
  const btn = document.getElementById("btnSend");
  btn.disabled = false;
  btn.textContent = "📨 送信する";
});
