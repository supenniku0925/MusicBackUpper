// background.js v15

const LOG = (...args) => console.log("[MusicBackUpper BG]", ...args);

const CATEGORY_MAP = {
  "1":  { label: "映画・アニメ",      icon: "🎬", key: "film" },
  "2":  { label: "自動車・乗り物",    icon: "🚗", key: "autos" },
  "10": { label: "音楽",              icon: "🎵", key: "music" },
  "15": { label: "ペット・動物",      icon: "🐾", key: "pets" },
  "17": { label: "スポーツ",          icon: "⚽", key: "sports" },
  "19": { label: "旅行・イベント",    icon: "✈️", key: "travel" },
  "20": { label: "ゲーム",            icon: "🎮", key: "gaming" },
  "22": { label: "ブログ・日常",      icon: "📝", key: "vlog" },
  "23": { label: "コメディ",          icon: "😂", key: "comedy" },
  "24": { label: "エンタメ",          icon: "🎭", key: "entertainment" },
  "25": { label: "ニュース・政治",    icon: "📰", key: "news" },
  "26": { label: "ハウツー・スタイル",icon: "💡", key: "howto" },
  "27": { label: "教育",              icon: "📚", key: "education" },
  "28": { label: "科学・テクノロジー",icon: "🔬", key: "science" },
  "29": { label: "NPO・社会活動",     icon: "🤝", key: "nonprofit" },
};

// ── 音楽キーワード（強化版） ───────────────────────────────
const MUSIC_TITLE_KEYWORDS = [
  // 日本語・定番
  "mv", "m/v", "歌ってみた", "弾いてみた", "演奏してみた", "歌詞",
  "full ver", "full version", "short ver", "カバー", "アコースティック",
  "ピアノ", "リミックス", "インスト", "オリジナル曲", "オリジナルソング",
  // VTuber・アニソン系でよく使われる表現
  "歌", "song", "music", "singing", "sing", "vocal",
  "オリジナル", "original song", "covered by", "arrange",
  "バラード", "ラップ", "ボカロ", "vocaloid",
  // 英語・定番
  "official video", "official audio", "official mv", "music video",
  "audio", "visualizer", "lyrics", "lyric", "cover", "acoustic",
  "piano", "remix", "instrumental", "feat.", "ft.", "prod.",
  "live ver", "live performance", "live session",
];

const MUSIC_CHANNEL_KEYWORDS = [
  "vevo", "records", "music", "ミュージック",
  "sony", "universal", "warner", "avex", "キングレコード",
  "lantis", "aniplex", "アニプレックス",
  // VTuber事務所
  "hololive", "ホロライブ", "nijisanji", "にじさんじ",
  "vspo", "あにまーれ", "774inc",
];

// ── 音楽判定（キーワード） ────────────────────────────────
function isMusicByKeyword(title, channelName) {
  const t = (title || "").toLowerCase();
  const c = (channelName || "").toLowerCase();
  const titleHit = MUSIC_TITLE_KEYWORDS.find((kw) => t.includes(kw.toLowerCase()));
  const channelHit = MUSIC_CHANNEL_KEYWORDS.find((kw) => c.includes(kw.toLowerCase()));
  if (titleHit) LOG(`キーワードヒット(タイトル): "${titleHit}"`);
  if (channelHit) LOG(`キーワードヒット(チャンネル): "${channelHit}"`);
  return !!(titleHit || channelHit);
}

// ── 手動登録チャンネルに一致するか確認 ───────────────────
function isMusicByCustomChannel(channelName, customChannels) {
  if (!customChannels || customChannels.length === 0) return false;
  const c = (channelName || "").toLowerCase();
  const hit = customChannels.find((ch) => c.includes(ch.toLowerCase().trim()));
  if (hit) LOG(`カスタムチャンネルヒット: "${hit}"`);
  return !!hit;
}

// ─── メッセージハンドラ ──────────────────────────────────────

// 起動時に既存データをマイグレーション（playsByYearがない古いデータに対応）
async function migrateData() {
  for (const storeKey of ["songs", "videos"]) {
    const data = await chrome.storage.local.get(storeKey);
    const store = data[storeKey] || {};
    let changed = false;
    for (const id of Object.keys(store)) {
      const item = store[id];
      if (!item.playsByYear) {
        // 初聴き年に全再生回数を割り当て（過去データの最善推定）
        const year = new Date(item.firstListened).getFullYear().toString();
        item.playsByYear = { [year]: item.playCount };
        changed = true;
      }
    }
    if (changed) await chrome.storage.local.set({ [storeKey]: store });
  }
  LOG("マイグレーション完了");
}

migrateData();
checkForUpdate();

// ─── アップデートチェック ────────────────────────────────────

const VERSION_URL = "https://raw.githubusercontent.com/supenniku0925/MusicBackUpper/main/version.json";

async function checkForUpdate() {
  try {
    const res = await fetch(VERSION_URL);
    if (!res.ok) return;
    const data = await res.json();
    const latest = data.version;
    const current = chrome.runtime.getManifest().version;

    if (isNewerVersion(latest, current)) {
      LOG(`アップデートあり: ${current} → ${latest}`);
      await chrome.storage.local.set({
        updateAvailable: {
          version: latest,
          releaseNotes: data.releaseNotes || "",
          downloadUrl: data.downloadUrl || "https://github.com/supenniku0925/MusicBackUpper/releases/latest",
        }
      });
      // ポップアップに通知
      chrome.runtime.sendMessage({ type: "UPDATE_AVAILABLE", payload: data }).catch(() => {});
    } else {
      // 古い通知をクリア
      await chrome.storage.local.remove("updateAvailable");
    }
  } catch (e) {
    LOG("アップデートチェック失敗:", e.message);
  }
}

function isNewerVersion(latest, current) {
  const l = latest.split(".").map(Number);
  const c = current.split(".").map(Number);
  for (let i = 0; i < 3; i++) {
    if ((l[i] || 0) > (c[i] || 0)) return true;
    if ((l[i] || 0) < (c[i] || 0)) return false;
  }
  return false;
}

// クイズモードタブのタイトルをページ内MutationObserverで最速書き換え
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status !== "loading") return;
  const data = await chrome.storage.local.get("quizModeTab");
  if (data.quizModeTab !== tabId) return;

  // ページが読み込まれたらMutationObserverを注入してタイトルを監視・即書き換え
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const QUIZ_TITLE = "🎵 ♪♪♪";
        document.title = QUIZ_TITLE;

        const titleEl = document.querySelector("title");
        if (!titleEl) return;

        const obs = new MutationObserver(() => {
          if (document.title !== QUIZ_TITLE) {
            document.title = QUIZ_TITLE;
          }
        });
        obs.observe(titleEl, { childList: true, characterData: true, subtree: true });
      },
    });
  } catch (e) {}
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "CHECK_AND_RECORD") { checkAndRecord(message.payload); }
  if (message.type === "MOVE_TO_SONGS") {
    moveToSongs(message.payload.videoId).then(sendResponse); return true;
  }
  if (message.type === "GET_SONGS")    { getSongs().then(sendResponse); return true; }
  if (message.type === "GET_VIDEOS")   { getVideos().then(sendResponse); return true; }
  if (message.type === "UPDATE_SONG")  { updateEntry("songs", message.payload).then(sendResponse); return true; }
  if (message.type === "UPDATE_VIDEO") { updateEntry("videos", message.payload).then(sendResponse); return true; }
  if (message.type === "DELETE_SONG")  { deleteEntry("songs", message.payload.videoId).then(sendResponse); return true; }
  if (message.type === "DELETE_VIDEO") { deleteEntry("videos", message.payload.videoId).then(sendResponse); return true; }
  if (message.type === "GET_SETTINGS") { getSettings().then(sendResponse); return true; }
  if (message.type === "SAVE_SETTINGS"){ saveSettings(message.payload).then(sendResponse); return true; }
  if (message.type === "GET_CATEGORY_MAP") { sendResponse(CATEGORY_MAP); return true; }
  if (message.type === "GET_CURRENT_TAB_ID") {
    sendResponse(sender.tab?.id || null); return true;
  }
  if (message.type === "OPEN_QUIZ_TAB") {
    openQuizTab(message.payload.url, message.payload.focusDuration).then(sendResponse); return true;
  }
  if (message.type === "CLOSE_TAB") {
    closeTab(message.payload.tabId).then(sendResponse); return true;
  }
  if (message.type === "GET_VIDEO_DURATION") {
    getVideoDuration(message.payload.videoId, message.payload.apiKey).then(sendResponse); return true;
  }
  if (message.type === "TEST_API_KEY") { testApiKey(message.payload.apiKey).then(sendResponse); return true; }
});

// ─── 判定メインフロー ────────────────────────────────────────

async function checkAndRecord({ videoId, title, channelName, url, timestamp }) {
  LOG(`判定開始: "${title}" / ch: "${channelName}"`);

  const settings = await getSettings();
  const apiKey = settings.youtubeApiKey || "";
  const enabledVideoGenres = settings.enabledVideoGenres || [];
  const customMusicChannels = settings.customMusicChannels || [];

  // ① 手動で音楽指定されたvideoId → 即座に音楽として記録
  const manualData = await chrome.storage.local.get("manualMusicIds");
  const manualMusicIds = manualData.manualMusicIds || [];
  if (manualMusicIds.includes(videoId)) {
    const { artist, composer, itunesTitle } = await resolveArtistInfo(title, "", channelName);
    await recordEntry("songs", {
      videoId, title, artist, composer, itunesTitle, url, timestamp,
      detectedBy: "manual", categoryId: "10",
    });
    LOG(`✅ 手動指定音楽として記録: "${title}"`);
    return;
  }

  // ① 手動登録チャンネルに一致 → 即座に音楽として記録
  if (isMusicByCustomChannel(channelName, customMusicChannels)) {
    const { artist, composer, itunesTitle, artistSource, composerSource } = await resolveArtistInfo(title, "", channelName);
    await recordEntry("songs", {
      videoId, title, artist, composer, artistSource, composerSource, url, timestamp,
      detectedBy: "custom_channel", categoryId: null,
    });
    LOG(`✅ カスタムチャンネルで音楽記録: "${title}" / 作曲者: "${composer}"(${composerSource})`);
    return;
  }

  let categoryId = null;
  let description = "";
  let detectedBy = "keyword";

  if (apiKey) {
    try {
      const result = await fetchVideoInfo(videoId, apiKey);
      categoryId = result.categoryId;
      description = result.description;
      detectedBy = "api";
      LOG(`API判定: categoryId=${categoryId} (${CATEGORY_MAP[categoryId]?.label || "不明"})`);
    } catch (e) {
      LOG(`API失敗: ${e.message} → キーワードにフォールバック`);
    }
  }

  // ② APIで音楽カテゴリ → 音楽
  if (categoryId === "10") {
    const { artist, composer, itunesTitle, artistSource, composerSource } = await resolveArtistInfo(title, description, channelName);
    await recordEntry("songs", {
      videoId, title, artist, composer, artistSource, composerSource, url, timestamp, detectedBy, categoryId,
    });
    LOG(`✅ API(音楽)で記録: "${title}" / 作曲者: "${composer}"(${composerSource})`);
    return;
  }

  // ③ APIが音楽以外でもキーワードで音楽と判定できれば音楽として記録
  const keywordIsMusic = isMusicByKeyword(title, channelName);
  if (keywordIsMusic) {
    const { artist, composer, itunesTitle, artistSource, composerSource } = await resolveArtistInfo(title, description, channelName);
    await recordEntry("songs", {
      videoId, title, artist, composer, artistSource, composerSource, url, timestamp,
      detectedBy: categoryId ? "keyword_override" : "keyword",
      categoryId,
    });
    LOG(`✅ キーワードで音楽記録: "${title}" / 作曲者: "${composer}"(${composerSource})`);
    return;
  }

  // ④ 音楽でない → 動画ジャンル判定
  LOG(`音楽でないと判定: "${title}"`);
  if (enabledVideoGenres.length === 0) {
    LOG("動画ジャンル未設定のためスキップ");
    return;
  }

  const genre = categoryId ? CATEGORY_MAP[categoryId] : null;
  if (categoryId && genre) {
    if (enabledVideoGenres.includes(genre.key)) {
      await recordEntry("videos", {
        videoId, title, url, timestamp, detectedBy, categoryId,
        genreKey: genre.key, genreLabel: genre.label, genreIcon: genre.icon,
      });
      LOG(`✅ 動画記録: "${title}" [${genre.label}]`);
    } else {
      LOG(`ジャンル「${genre.label}」は無効のためスキップ`);
    }
  } else if (!categoryId && enabledVideoGenres.includes("other")) {
    await recordEntry("videos", {
      videoId, title, url, timestamp, detectedBy: "keyword", categoryId: null,
      genreKey: "other", genreLabel: "その他", genreIcon: "📹",
    });
    LOG(`✅ 動画(その他)記録: "${title}"`);
  } else {
    LOG("記録対象外");
  }
}

// ─── API関連 ────────────────────────────────────────────────

async function fetchVideoInfo(videoId, apiKey) {
  const res = await fetch(
    `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${apiKey}`
  );
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  if (!data.items?.length) throw new Error("動画情報なし");
  const snippet = data.items[0].snippet;
  return {
    categoryId: snippet.categoryId,
    description: snippet.description || "",
  };
}

// ① iTunes Search APIで歌手名を取得（同名楽曲はチャンネル名で絞り込み）
async function fetchArtistFromItunes(title, channelName) {
  try {
    const cleanTitle = title
      .replace(/【.*?】|\[.*?\]|（.*?）|\(.*?\)/g, "")
      .replace(/(MV|mv|Official|official|歌ってみた|covered by|cover).*/i, "")
      .trim()
      .slice(0, 60);

    const res1 = await fetch(
      `https://itunes.apple.com/search?term=${encodeURIComponent(cleanTitle)}&media=music&limit=5&country=JP`
    );
    if (!res1.ok) return null;
    const data1 = await res1.json();
    if (data1.resultCount === 0) return null;

    if (data1.resultCount === 1) {
      const result = data1.results[0];
      LOG(`iTunes取得（単独ヒット）: "${result.artistName}" / trackName: "${result.trackName}"`);
      return { artist: result.artistName, itunesTitle: result.trackName };
    }

    const cleanChannel = (channelName || "")
      .replace(/\s*(official|ch|channel|music|records).*/i, "")
      .trim();

    if (cleanChannel) {
      const res2 = await fetch(
        `https://itunes.apple.com/search?term=${encodeURIComponent(`${cleanTitle} ${cleanChannel}`)}&media=music&limit=3&country=JP`
      );
      if (res2.ok) {
        const data2 = await res2.json();
        if (data2.resultCount > 0) {
          const result = data2.results[0];
          LOG(`iTunes取得（チャンネル名で絞り込み）: "${result.artistName}" / trackName: "${result.trackName}"`);
          return { artist: result.artistName, itunesTitle: result.trackName };
        }
      }
    }

    LOG(`iTunes複数ヒットで絞り込み失敗 → 説明欄にフォールバック`);
    return null;
  } catch (e) {
    LOG(`iTunes API失敗: ${e.message}`);
    return null;
  }
}

// ② YouTube説明欄から作曲者・歌手名をパース
function extractInfoFromDescription(description) {
  if (!description) return { composer: null, artist: null };

  const composerPatterns = [
    /作曲[者]?\s*[：:／/・]\s*([^\n／/・、,]{1,50})/,
    /作編曲\s*[：:／/]\s*([^\n／/・、,]{1,50})/,
    /作曲\s*・\s*編曲\s*[：:]\s*([^\n]{1,50})/,
    /[Cc]omposed?\s+[Bb]y\s*[：:]?\s*([^\n]{1,50})/,
    /[Cc]omposer\s*[：:]\s*([^\n]{1,50})/,
    /[Mm]usic\s*[：:／/]\s*([^\n]{1,50})/,
    /[Mm]usic\s+[Bb]y\s*[：:]?\s*([^\n]{1,50})/,
  ];

  const artistPatterns = [
    /歌\s*[：:／/・]\s*([^\n／/・、,]{1,50})/,
    /歌唱\s*[：:]\s*([^\n]{1,50})/,
    /vocal\s*[：:／/]\s*([^\n]{1,50})/i,
    /singer\s*[：:]\s*([^\n]{1,50})/i,
    /performed?\s+by\s*[：:]?\s*([^\n]{1,50})/i,
    /[Vv]o\s*[：:.]\s*([^\n]{1,50})/,
  ];

  function parsePattern(patterns) {
    for (const pattern of patterns) {
      const match = description.match(pattern);
      if (match) {
        let val = match[1]
          .split(/[\n　]|https?:/)[0]
          .replace(/（.*?）|\(.*?\)/g, "")
          .replace(/[　\s]+/g, " ")
          .replace(/[、,。.]\s*$/, "")
          .trim();
        if (val.length > 0 && val.length < 50) return val;
      }
    }
    return null;
  }

  const composer = parsePattern(composerPatterns);
  const artist = parsePattern(artistPatterns);
  if (composer) LOG(`説明欄から作曲者: "${composer}"`);
  if (artist) LOG(`説明欄から歌手名: "${artist}"`);
  return { composer, artist };
}

// 歌手名・作曲者を統合取得
async function resolveArtistInfo(title, description, channelName) {
  const itunesResult = await fetchArtistFromItunes(title, channelName);
  const descInfo = extractInfoFromDescription(description);

  const artist = (itunesResult?.artist) || descInfo.artist || "";
  const itunesTitle = itunesResult?.itunesTitle || null;
  const composer = descInfo.composer || "";
  const artistSource = itunesResult ? "itunes" : (descInfo.artist ? "description" : "none");
  const composerSource = descInfo.composer ? "description" : "none";

  LOG(`歌手名: "${artist}"(${artistSource}) / 作曲者: "${composer}"(${composerSource}) / iTunesタイトル: "${itunesTitle}"`);
  return { artist, composer, itunesTitle, artistSource, composerSource };
}

async function openQuizTab(url, focusDuration = 1) {
  const currentWindow = await chrome.windows.getCurrent();

  const win = await chrome.windows.create({
    url, type: "popup",
    width: 320, height: 180,
    left: 0, top: 0, focused: true,
  });

  const tabId = win.tabs[0].id;
  const windowId = win.id;
  await chrome.storage.local.set({ quizModeTab: tabId, quizModeWindow: windowId });

  setTimeout(async () => {
    try {
      await chrome.windows.update(windowId, { state: "minimized" });
      await chrome.windows.update(currentWindow.id, { focused: true });
    } catch (e) {}
  }, focusDuration * 1000);

  return { tabId };
}

async function closeTab(tabId) {
  try {
    const data = await chrome.storage.local.get("quizModeWindow");
    if (data.quizModeWindow) {
      await chrome.windows.remove(data.quizModeWindow);
    } else {
      await chrome.tabs.remove(tabId);
    }
    await chrome.storage.local.remove(["quizModeTab", "quizModeWindow", "quizChallengeMode"]);
    return { ok: true };
  } catch (e) {
    await chrome.storage.local.remove(["quizModeTab", "quizModeWindow", "quizChallengeMode"]);
    return { ok: true };
  }
}

async function getVideoDuration(videoId, apiKey) {
  try {
    const res = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=${videoId}&key=${apiKey}`
    );
    const data = await res.json();
    if (data.error) return { ok: false, duration: null };
    if (!data.items?.length) return { ok: false, duration: null };
    // ISO 8601形式（PT3M45S）を秒数に変換
    const iso = data.items[0].contentDetails.duration;
    const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    const h = parseInt(match[1] || 0);
    const m = parseInt(match[2] || 0);
    const s = parseInt(match[3] || 0);
    const duration = h * 3600 + m * 60 + s;
    return { ok: true, duration };
  } catch (e) {
    return { ok: false, duration: null };
  }
}

async function testApiKey(apiKey) {
  try {
    const res = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=dQw4w9WgXcQ&key=${apiKey}`
    );
    const data = await res.json();
    if (data.error) return { ok: false, message: data.error.message };
    if (data.items?.length > 0) return { ok: true, message: "接続成功！APIキーは有効です" };
    return { ok: false, message: "レスポンスが空です" };
  } catch (e) {
    return { ok: false, message: e.message };
  }
} 

async function recordEntry(storeKey, entry) {
  const data = await chrome.storage.local.get(storeKey);
  const store = data[storeKey] || {};
  const year = new Date(entry.timestamp).getFullYear().toString();

  if (store[entry.videoId]) {
    const existing = store[entry.videoId];
    existing.playCount += 1;
    existing.lastPlayed = entry.timestamp;
    // 年別カウント
    if (!existing.playsByYear) existing.playsByYear = {};
    existing.playsByYear[year] = (existing.playsByYear[year] || 0) + 1;
  } else {
    store[entry.videoId] = {
      ...entry,
      playCount: 1,
      firstListened: entry.timestamp,
      playsByYear: { [year]: 1 },
    };
  }

  await chrome.storage.local.set({ [storeKey]: store });
  chrome.runtime.sendMessage({ type: "DATA_UPDATED", store: storeKey }).catch(() => {});
}

async function moveToSongs(videoId) {
  const data = await chrome.storage.local.get(["songs", "videos", "manualMusicIds"]);
  const songs = data.songs || {};
  const videos = data.videos || {};
  const manualMusicIds = data.manualMusicIds || [];

  const video = videos[videoId];
  if (!video) return { success: false, message: "動画が見つかりません" };

  // 音楽ストレージに追加
  if (songs[videoId]) {
    songs[videoId].playCount += video.playCount;
    songs[videoId].lastPlayed = video.lastPlayed || video.firstListened;
  } else {
    songs[videoId] = {
      videoId:       video.videoId,
      title:         video.title,
      composer:      video.composer || "",
      artist:        video.artist || "",
      url:           video.url,
      playCount:     video.playCount,
      firstListened: video.firstListened,
      lastPlayed:    video.lastPlayed || video.firstListened,
      detectedBy:    "manual",
      categoryId:    "10",
    };
  }

  // 動画ストレージから削除
  delete videos[videoId];

  // 手動で音楽指定したvideoIdを記録（次回から強制的に音楽として扱う）
  if (!manualMusicIds.includes(videoId)) {
    manualMusicIds.push(videoId);
  }

  await chrome.storage.local.set({ songs, videos, manualMusicIds });
  chrome.runtime.sendMessage({ type: "DATA_UPDATED" }).catch(() => {});
  return { success: true };
}

async function getSongs() {
  const d = await chrome.storage.local.get("songs");
  return d.songs || {};
}
async function getVideos() {
  const d = await chrome.storage.local.get("videos");
  return d.videos || {};
}
async function updateEntry(storeKey, item) {
  const data = await chrome.storage.local.get(storeKey);
  const store = data[storeKey] || {};
  if (store[item.videoId]) {
    store[item.videoId] = { ...store[item.videoId], ...item };
    await chrome.storage.local.set({ [storeKey]: store });
    return { success: true };
  }
  return { success: false };
}
async function deleteEntry(storeKey, videoId) {
  const data = await chrome.storage.local.get(storeKey);
  const store = data[storeKey] || {};
  delete store[videoId];
  await chrome.storage.local.set({ [storeKey]: store });
  return { success: true };
}
async function getSettings() {
  const d = await chrome.storage.local.get("settings");
  return d.settings || { youtubeApiKey: "", enabledVideoGenres: [], customMusicChannels: [] };
}
async function saveSettings(settings) {
  await chrome.storage.local.set({ settings });
  return { success: true };
}
