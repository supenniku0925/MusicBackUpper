let allVideos = [];
let activeGenre = "all";

async function main() {
  const videosMap = await new Promise((res) =>
    chrome.runtime.sendMessage({ type: "GET_VIDEOS" }, res)
  );
  allVideos = Object.values(videosMap);
  renderPage();
  buildGenreFilter();
  initTabs();
}

function subHtml(v) {
  return v.genreLabel
    ? `<div class="song-sub genre-tag">${v.genreIcon || "📹"} ${esc(v.genreLabel)}</div>`
    : "";
}

function renderPage() {
  const filtered = activeGenre === "all"
    ? allVideos
    : allVideos.filter((v) => v.genreKey === activeGenre);

  const genres = new Set(allVideos.map((v) => v.genreKey).filter(Boolean));

  renderSummary(filtered, [
    { label: "登録動画数", value: filtered.length },
    { label: "総再生回数", value: filtered.reduce((s, x) => s + x.playCount, 0) },
    { label: "ジャンル数",  value: genres.size },
    { label: "活動年数",   value: new Set(filtered.map((x) => new Date(x.firstListened).getFullYear())).size },
  ]);

  renderFirstTimeline(filtered, document.getElementById("tab-first"), subHtml);
  renderPlaysTimeline(filtered, document.getElementById("tab-plays"), subHtml);
  renderCalendarView(filtered, document.getElementById("tab-calendar"), subHtml);
}

function buildGenreFilter() {
  const genres = [...new Set(allVideos.map((v) => v.genreKey).filter(Boolean))];
  const container = document.getElementById("genreFilterHeader");

  const all = [{ key: "all", label: "すべて", icon: "📋" },
    ...genres.map((k) => {
      const v = allVideos.find((x) => x.genreKey === k);
      return { key: k, label: v.genreLabel, icon: v.genreIcon };
    })];

  container.innerHTML = all.map((g) =>
    `<span class="genre-chip-header ${activeGenre === g.key ? "active" : ""}" data-key="${g.key}">
      ${g.icon} ${g.label}
    </span>`
  ).join("");

  container.querySelectorAll(".genre-chip-header").forEach((el) => {
    el.addEventListener("click", () => {
      activeGenre = el.dataset.key;
      renderPage();
      buildGenreFilter();
    });
  });
}

main();
