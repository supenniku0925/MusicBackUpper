async function main() {
  const songsMap = await new Promise((res) =>
    chrome.runtime.sendMessage({ type: "GET_SONGS" }, res)
  );
  const items = Object.values(songsMap);
  const subHtml = (s) => {
    const parts = [];
    if (s.artist) parts.push(`🎤 ${esc(s.artist)}`);
    if (s.composer) parts.push(`🎼 ${esc(s.composer)}`);
    return parts.length ? `<div class="song-sub">${parts.join("　")}</div>` : "";
  };

  renderSummary(items, [
    { label: "登録曲数",     value: items.length },
    { label: "総再生回数",   value: items.reduce((s, x) => s + x.playCount, 0) },
    { label: "アーティスト数", value: new Set(items.map((x) => x.artist).filter(Boolean)).size },
    { label: "作曲者数",     value: new Set(items.map((x) => x.composer).filter(Boolean)).size },
    { label: "活動年数",     value: new Set(items.map((x) => new Date(x.firstListened).getFullYear())).size },
  ]);

  renderFirstTimeline(items, document.getElementById("tab-first"), subHtml);
  renderPlaysTimeline(items, document.getElementById("tab-plays"), subHtml);
  renderCalendarView(items, document.getElementById("tab-calendar"), subHtml);
  initTabs();
}
main();
