// quiz.js v21

const msg = (type, payload) =>
  new Promise((res) => chrome.runtime.sendMessage({ type, payload }, res));

// ── 状態 ────────────────────────────────────────────────────
let allSongs = [];
let quizSongs = [];
let currentIndex = 0;
let currentSong = null;
let currentType = "intro";
let currentDuration = null;
let currentStartSec = 0;
let score = { correct: 0, wrong: 0 };
let apiKey = "";
let stopTimer = null;
let minPlayCount = 3;
let introDuration = 3;
let outroDuration = 3;
let quizMode = "both"; // "both" | "intro" | "outro"
let focusDuration = 1; // 再生待機時間（秒）
let answered = false;
let pendingPlay = false;

// ── 初期化 ───────────────────────────────────────────────────
async function init() {
  const settings = await msg("GET_SETTINGS");
  apiKey = settings.youtubeApiKey || "";

  if (!apiKey) {
    document.getElementById("apiWarn").style.display = "block";
  }

  const songsMap = await msg("GET_SONGS");
  allSongs = Object.values(songsMap);

  const slider = document.getElementById("minPlaySlider");
  const sliderVal = document.getElementById("sliderVal");
  const maxPlay = Math.max(10, ...allSongs.map((s) => s.playCount));
  slider.max = maxPlay;

  slider.addEventListener("input", () => {
    minPlayCount = parseInt(slider.value);
    sliderVal.textContent = minPlayCount;
    updateSongCount();
  });

  const introSlider = document.getElementById("introSlider");
  const outroSlider = document.getElementById("outroSlider");
  introSlider.addEventListener("input", () => {
    introDuration = parseInt(introSlider.value);
    document.getElementById("introVal").textContent = introDuration;
  });
  outroSlider.addEventListener("input", () => {
    outroDuration = parseInt(outroSlider.value);
    document.getElementById("outroVal").textContent = outroDuration;
  });

  const focusSlider = document.getElementById("focusSlider");
  focusSlider.addEventListener("input", () => {
    focusDuration = parseFloat(focusSlider.value);
    document.getElementById("focusVal").textContent = focusDuration.toFixed(1);
  });

  document.querySelectorAll(".mode-btn[data-mode]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".mode-btn[data-mode]").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      quizMode = btn.dataset.mode;
      if ((quizMode === "outro" || quizMode === "both") && !apiKey) {
        document.getElementById("apiWarn").style.display = "block";
      } else {
        document.getElementById("apiWarn").style.display = "none";
      }
    });
  });

  updateSongCount();

  document.getElementById("btnStart").addEventListener("click", startQuiz);
  document.getElementById("btnPlay").addEventListener("click", playClip);
  document.getElementById("btnAnswer").addEventListener("click", checkAnswer);
  document.getElementById("btnNext").addEventListener("click", nextQuestion);
  document.getElementById("answerInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") checkAnswer();
  });
  document.getElementById("btnRetry").addEventListener("click", resetToSetup);
  document.getElementById("btnBack").addEventListener("click", resetToSetup);
}

function updateSongCount() {
  const filtered = allSongs.filter((s) => s.playCount >= minPlayCount);
  document.getElementById("songCountPreview").innerHTML =
    `再生回数 <strong>${minPlayCount}回以上</strong> の曲：<strong>${filtered.length}曲</strong>`;
  document.getElementById("btnStart").disabled = filtered.length < 1;
}

// ── リセット ─────────────────────────────────────────────────
function resetToSetup() {
  clearTimeout(stopTimer);
  score = { correct: 0, wrong: 0 };
  currentIndex = 0;
  answered = false;
  pendingPlay = false;

  document.getElementById("resultScreen").style.display = "none";
  document.getElementById("quizScreen").style.display = "none";
  document.getElementById("setupScreen").style.display = "block";
  document.getElementById("scoreBoard").style.display = "none";

  resetInputUI();
  updateSongCount();
}

function resetInputUI() {
  const input = document.getElementById("answerInput");
  input.value = "";
  input.className = "answer-input";
  input.disabled = false;
  document.getElementById("resultBox").className = "result-box";
  document.getElementById("btnNext").className = "btn-next";
  document.getElementById("btnAnswer").disabled = false;
  document.getElementById("btnPlay").textContent = "▶ YouTubeで再生する";
  document.getElementById("playHint").textContent = "🎵 ボタンを押して曲を再生してください";
}

// ── クイズ開始 ───────────────────────────────────────────────
function startQuiz() {
  quizSongs = allSongs
    .filter((s) => s.playCount >= minPlayCount)
    .sort(() => Math.random() - 0.5)
    .slice(0, 10);

  currentIndex = 0;
  score = { correct: 0, wrong: 0 };

  document.getElementById("setupScreen").style.display = "none";
  document.getElementById("quizScreen").style.display = "block";
  document.getElementById("scoreBoard").style.display = "flex";

  updateScoreBoard();
  loadQuestion();
}

async function loadQuestion() {
  answered = false;
  pendingPlay = false;
  clearTimeout(stopTimer);
  currentSong = quizSongs[currentIndex];
  currentDuration = null;

  // quizModeに応じてイントロ/アウトロを決定
  if (quizMode === "intro") {
    currentType = "intro";
  } else if (quizMode === "outro") {
    currentType = "outro";
  } else {
    currentType = apiKey ? (Math.random() < 0.5 ? "intro" : "outro") : "intro";
  }

  // アウトロの場合は動画尺を取得
  if (currentType === "outro" && apiKey) {
    const result = await msg("GET_VIDEO_DURATION", {
      videoId: currentSong.videoId,
      apiKey,
    });
    if (result && result.ok && result.duration > outroDuration + 3) {
      currentDuration = result.duration;
    } else {
      currentType = "intro";
    }
  }

  // 開始秒数
  currentStartSec = currentType === "intro"
    ? 0
    : Math.max(0, currentDuration - outroDuration);

  // UI更新
  const typeLabel = currentType === "intro" ? "イントロ" : "アウトロ";
  const clipSec = currentType === "intro" ? introDuration : outroDuration;
  document.getElementById("quizTypeBadge").textContent =
    currentType === "intro" ? `🎵 イントロ ${introDuration}秒` : `🎵 アウトロ ${outroDuration}秒`;
  document.getElementById("quizProgress").textContent =
    `${currentIndex + 1} / ${quizSongs.length}`;
  document.getElementById("playTypeDesc").textContent =
    currentType === "intro"
      ? `曲の最初${introDuration}秒が再生されます`
      : `曲の最後${outroDuration}秒が再生されます（${Math.floor(currentDuration - outroDuration)}秒〜）`;
  document.getElementById("playHint").textContent =
    `🎵 ${typeLabel}（${clipSec}秒）を聴いて曲名を当ててください`;

  resetInputUI();
}

// ── 再生（挑戦モード対応） ────────────────────────────────
async function playClip() {
  if (!currentSong) return;

  const videoId = currentSong.videoId;
  const startSec = Math.floor(currentStartSec);
  const url = `https://www.youtube.com/watch?v=${videoId}&t=${startSec}s&autoplay=1`;
  const clipSec = currentType === "intro" ? introDuration : outroDuration;

  document.getElementById("btnPlay").disabled = true;
  document.getElementById("btnPlay").textContent = "⏳ 再生中...";
  document.getElementById("playHint").textContent = `🎵 ${clipSec}秒後に自動で終了します`;

  const result = await msg("OPEN_QUIZ_TAB", { url, focusDuration });
  const tabId = result.tabId;

  // 指定秒数後にタブを閉じてクイズ画面に戻す
  setTimeout(async () => {
    await msg("CLOSE_TAB", { tabId });
    document.getElementById("btnPlay").disabled = false;
    document.getElementById("btnPlay").textContent = "▶ もう一度再生する";
    document.getElementById("playHint").textContent = "🎵 曲名を入力して回答してください";
    document.getElementById("answerInput").focus();
  }, clipSec * 1000);
}

// ── 回答チェック ─────────────────────────────────────────────
function checkAnswer() {
  if (answered) return;
  const input = document.getElementById("answerInput");
  const userAnswer = input.value.trim();
  if (!userAnswer) return;

  answered = true;
  const correct = isCorrectAnswer(userAnswer, currentSong.title, currentSong.itunesTitle);
  const resultBox = document.getElementById("resultBox");

  if (correct) {
    score.correct++;
    input.className = "answer-input correct";
    resultBox.className = "result-box correct";
    document.getElementById("resultMsg").textContent = "✅ 正解！";
  } else {
    score.wrong++;
    input.className = "answer-input wrong";
    resultBox.className = "result-box wrong";
    document.getElementById("resultMsg").textContent = "❌ 不正解";
  }

  document.getElementById("resultAnswer").textContent = `正解：${currentSong.title}`;
  input.disabled = true;
  document.getElementById("btnAnswer").disabled = true;
  document.getElementById("btnNext").className = "btn-next show";
  updateScoreBoard();
}

// ── 正誤判定 ─────────────────────────────────────────────────
function isCorrectAnswer(userInput, correctTitle, itunesTitle) {
  const cleanTitle = (str) =>
    str
      .replace(/【.*?】/g, "")
      .replace(/\[.*?\]/g, "")
      .replace(/（[^）]*?）/g, "")
      .replace(/\([^)]*?\)/g, "")
      .replace(/official\s*(video|audio|mv|music\s*video)?/gi, "")
      .replace(/music\s*video/gi, "")
      .replace(/full\s*(ver|version|movie)/gi, "")
      .replace(/short\s*(ver|version)/gi, "")
      .replace(/lyric\s*video/gi, "")
      .replace(/feat\.?\s*[^\s]+/gi, "")
      .replace(/ft\.?\s*[^\s]+/gi, "")
      .replace(/\//g, " ")
      .trim();

  const normalize = (str) =>
    cleanTitle(str)
      .toLowerCase()
      .replace(/[\u30A1-\u30F6]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0x60))
      .replace(/[\s　「」【】『』（）()[\]\/\\~〜・\-_,.!?！？♪♫]/g, "");

  const u = normalize(userInput);
  if (!u) return false;

  // iTunesタイトルがある場合はそちらでも判定（よりクリーンなタイトル）
  const targets = [normalize(correctTitle)];
  if (itunesTitle) targets.push(normalize(itunesTitle));

  for (const c of targets) {
    if (!c) continue;

    // 完全一致
    if (u === c) return true;

    // 部分一致：正解の50%以上（文字数制限なし）
    const minLen = Math.max(1, Math.floor(c.length * 0.5));
    if (c.includes(u) && u.length >= minLen) return true;
    if (u.includes(c) && c.length >= 1) return true;

    // 編集距離：80%以上の類似度
    const dist = levenshtein(u, c);
    const maxLen = Math.max(u.length, c.length);
    if (maxLen > 0 && (1 - dist / maxLen) >= 0.8) return true;
  }

  return false;
}

function levenshtein(a, b) {
  const dp = Array.from({ length: a.length + 1 }, (_, i) =>
    Array.from({ length: b.length + 1 }, (_, j) =>
      i === 0 ? j : j === 0 ? i : 0
    )
  );
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[a.length][b.length];
}

// ── 次の問題・スコア・結果 ───────────────────────────────────
function nextQuestion() {
  currentIndex++;
  if (currentIndex >= quizSongs.length) {
    showResult();
  } else {
    loadQuestion();
  }
}

function updateScoreBoard() {
  document.getElementById("scoreCorrect").textContent = score.correct;
  document.getElementById("scoreWrong").textContent = score.wrong;
  document.getElementById("scoreTotal").textContent =
    Math.min(currentIndex + 1, quizSongs.length);
}

function showResult() {
  clearTimeout(stopTimer);
  document.getElementById("quizScreen").style.display = "none";
  document.getElementById("scoreBoard").style.display = "none";
  document.getElementById("resultScreen").style.display = "block";

  const total = quizSongs.length;
  const pct = Math.round((score.correct / total) * 100);
  document.getElementById("finalScore").textContent = `${score.correct}/${total}`;

  let title, desc;
  if (pct === 100)    { title = "🎉 パーフェクト！"; desc = "全問正解！あなたは音楽マスターです"; }
  else if (pct >= 80) { title = "🎵 すごい！";       desc = "かなりの実力です！"; }
  else if (pct >= 60) { title = "👍 なかなか！";     desc = "もう少しで上級者です"; }
  else if (pct >= 40) { title = "🎧 もう少し！";     desc = "もっと聴き込もう！"; }
  else                { title = "😅 修行が必要";     desc = "またチャレンジしてみよう！"; }

  document.getElementById("resultTitle").textContent = title;
  document.getElementById("resultDesc").textContent = desc;
}

init();
