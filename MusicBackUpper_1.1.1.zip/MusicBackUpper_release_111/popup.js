// popup.js v3

let allSongs = {};
let allVideos = {};
let musicSearch = "";
let videoSearch = "";
let activeGenreFilter = "all";
let currentTab = "music";

const msg = (type, payload) =>
  new Promise((res) => chrome.runtime.sendMessage({ type, payload }, res));

async function init() {
  await loadAll();

  // タブ切り替え
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      currentTab = btn.dataset.tab;
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`tab-${currentTab}`).classList.add("active");
    });
  });

  document.getElementById("musicSearch").addEventListener("input", (e) => {
    musicSearch = e.target.value.toLowerCase();
    renderMusic();
  });
  document.getElementById("videoSearch").addEventListener("input", (e) => {
    videoSearch = e.target.value.toLowerCase();
    renderVideos();
  });

  document.getElementById("btnSettings").addEventListener("click", () =>
    chrome.runtime.openOptionsPage()
  );
  document.getElementById("btnGuide").addEventListener("click", () =>
    chrome.tabs.create({ url: chrome.runtime.getURL("guide.html") })
  );
  document.getElementById("btnFeedback").addEventListener("click", () =>
    chrome.tabs.create({ url: chrome.runtime.getURL("feedback.html") })
  );
  document.getElementById("btnQuiz").addEventListener("click", () =>
    chrome.tabs.create({ url: chrome.runtime.getURL("quiz.html") })
  );
  document.getElementById("btnMusicTimeline").addEventListener("click", () =>
    chrome.tabs.create({ url: chrome.runtime.getURL("timeline_music.html") })
  );
  document.getElementById("btnVideoTimeline").addEventListener("click", () =>
    chrome.tabs.create({ url: chrome.runtime.getURL("timeline_video.html") })
  );

  // アップデート通知バナー
  const updateData = await new Promise((res) =>
    chrome.storage.local.get("updateAvailable", (d) => res(d.updateAvailable))
  );
  if (updateData) {
    const banner = document.getElementById("updateBanner");
    document.getElementById("updateText").textContent =
      `v${updateData.version} が利用可能です${updateData.releaseNotes ? `（${updateData.releaseNotes}）` : ""}`;
    document.getElementById("updateLink").href = updateData.downloadUrl;
    banner.style.display = "flex";
  }

  // UPDATE_AVAILABLEメッセージを受け取ったらバナーを表示
  chrome.runtime.onMessage.addListener((m) => {
    if (m.type === "UPDATE_AVAILABLE") {
      const banner = document.getElementById("updateBanner");
      document.getElementById("updateText").textContent =
        `v${m.payload.version} が利用可能です${m.payload.releaseNotes ? `（${m.payload.releaseNotes}）` : ""}`;
      document.getElementById("updateLink").href = m.payload.downloadUrl;
      banner.style.display = "flex";
    }
    if (m.type === "DATA_UPDATED") loadAll();
  });
}

async function loadAll() {
  [allSongs, allVideos] = await Promise.all([
    msg("GET_SONGS"), msg("GET_VIDEOS"),
  ]);
  updateMusicStats();
  updateVideoStats();
  renderMusic();
  renderVideos();
  renderGenreFilter();
  updateTabCounts();
}

function updateTabCounts() {
  document.getElementById("musicCount").textContent =
    Object.keys(allSongs).length ? `(${Object.keys(allSongs).length})` : "";
  document.getElementById("videoCount").textContent =
    Object.keys(allVideos).length ? `(${Object.keys(allVideos).length})` : "";
}

// ── 音楽 ────────────────────────────────────────────────────

function updateMusicStats() {
  const songs = Object.values(allSongs);
  document.getElementById("mStatSongs").textContent = songs.length;
  document.getElementById("mStatPlays").textContent = songs.reduce((s, x) => s + x.playCount, 0);
  document.getElementById("mStatComposers").textContent =
    new Set(songs.map((s) => s.artist).filter(Boolean)).size;
}

function renderMusic() {
  const container = document.getElementById("musicList");
  let songs = Object.values(allSongs);
  if (musicSearch)
    songs = songs.filter(
      (s) =>
        s.title.toLowerCase().includes(musicSearch) ||
        (s.composer || "").toLowerCase().includes(musicSearch)
    );
  songs.sort((a, b) => new Date(b.firstListened) - new Date(a.firstListened));

  if (!songs.length) {
    container.innerHTML = emptyState(
      musicSearch ? "🔍" : "🎧",
      musicSearch ? "該当する曲が見つかりません" : "YouTubeで曲を30秒以上視聴すると<br/>自動で記録されます"
    );
    return;
  }

  container.innerHTML = songs.map((s) => musicCard(s)).join("");
  songs.forEach((s) => bindCardEvents(s.videoId, "song"));
}

function musicCard(s) {
  const d = fmtDate(s.firstListened);
  return `
    <div class="song-card" id="card-${s.videoId}">
      <div class="song-header">
        <a class="song-title-link" href="${s.url}" target="_blank">${esc(s.title)}</a>
        <div class="song-actions">
          <button class="btn-icon" id="edit-btn-${s.videoId}">✏️</button>
          <button class="btn-icon del" id="delete-btn-${s.videoId}">🗑</button>
        </div>
      </div>
      <div class="song-meta">
        <span class="meta-sub">🎤 ${s.artist ? esc(s.artist) : '<span style="color:#4a4a6a;font-style:italic">歌手未設定</span>'}</span>
        <span class="meta-sub">🎼 ${s.composer ? esc(s.composer) : '<span style="color:#4a4a6a;font-style:italic">作曲者未設定</span>'}</span>
        <span class="meta-sub">📅 ${d}</span>
        <span class="play-badge">▶ ${s.playCount}回</span>
      </div>
      <div class="edit-form" id="edit-form-${s.videoId}">
        <input class="edit-input" id="edit-title-${s.videoId}" value="${esc(s.title)}" placeholder="曲タイトル" />
        <input class="edit-input" id="edit-artist-${s.videoId}" value="${esc(s.artist || "")}" placeholder="歌手名" />
        <input class="edit-input" id="edit-composer-${s.videoId}" value="${esc(s.composer || "")}" placeholder="作曲者名" />
        <div class="edit-row">
          <button class="btn-save" id="save-btn-${s.videoId}">保存</button>
          <button class="btn-cancel" id="cancel-btn-${s.videoId}">キャンセル</button>
        </div>
      </div>
    </div>`;
}

// ── 動画 ────────────────────────────────────────────────────

function updateVideoStats() {
  const videos = Object.values(allVideos);
  document.getElementById("vStatVideos").textContent = videos.length;
  document.getElementById("vStatPlays").textContent = videos.reduce((s, x) => s + x.playCount, 0);
  document.getElementById("vStatGenres").textContent =
    new Set(videos.map((v) => v.genreKey).filter(Boolean)).size;
}

function renderGenreFilter() {
  const videos = Object.values(allVideos);
  const genres = [...new Set(videos.map((v) => v.genreKey).filter(Boolean))];
  const container = document.getElementById("genreFilter");

  const items = [{ key: "all", label: "すべて", icon: "📋" },
    ...genres.map((k) => {
      const v = videos.find((v) => v.genreKey === k);
      return { key: k, label: v.genreLabel, icon: v.genreIcon };
    })];

  container.innerHTML = items
    .map(
      (g) =>
        `<span class="genre-chip ${activeGenreFilter === g.key ? "active" : ""}"
           data-genre="${g.key}">${g.icon} ${g.label}</span>`
    )
    .join("");

  container.querySelectorAll(".genre-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      activeGenreFilter = chip.dataset.genre;
      renderGenreFilter();
      renderVideos();
    });
  });
}

function renderVideos() {
  const container = document.getElementById("videoList");
  let videos = Object.values(allVideos);

  if (activeGenreFilter !== "all")
    videos = videos.filter((v) => v.genreKey === activeGenreFilter);
  if (videoSearch)
    videos = videos.filter((v) => v.title.toLowerCase().includes(videoSearch));

  videos.sort((a, b) => new Date(b.firstListened) - new Date(a.firstListened));

  if (!videos.length) {
    container.innerHTML = emptyState(
      videoSearch || activeGenreFilter !== "all" ? "🔍" : "🎬",
      videoSearch || activeGenreFilter !== "all"
        ? "該当する動画が見つかりません"
        : "設定でジャンルを有効にすると<br/>動画が記録されます"
    );
    return;
  }

  container.innerHTML = videos.map((v) => videoCard(v)).join("");
  videos.forEach((v) => bindCardEvents(v.videoId, "video"));
}

function videoCard(v) {
  const d = fmtDate(v.firstListened);
  return `
    <div class="song-card" id="card-${v.videoId}">
      <div class="song-header">
        <a class="song-title-link" href="${v.url}" target="_blank">${esc(v.title)}</a>
        <div class="song-actions">
          <button class="btn-icon" id="move-btn-${v.videoId}" title="音楽に移動">🎵</button>
          <button class="btn-icon" id="edit-btn-${v.videoId}">✏️</button>
          <button class="btn-icon del" id="delete-btn-${v.videoId}">🗑</button>
        </div>
      </div>
      <div class="song-meta">
        <span class="genre-badge">${v.genreIcon || "📹"} ${v.genreLabel || "不明"}</span>
        <span class="meta-sub">📅 ${d}</span>
        <span class="play-badge">▶ ${v.playCount}回</span>
      </div>
      <div class="edit-form" id="edit-form-${v.videoId}">
        <input class="edit-input" id="edit-title-${v.videoId}" value="${esc(v.title)}" placeholder="動画タイトル" />
        <div class="edit-row">
          <button class="btn-save" id="save-btn-${v.videoId}">保存</button>
          <button class="btn-cancel" id="cancel-btn-${v.videoId}">キャンセル</button>
        </div>
      </div>
    </div>`;
}

// ── カード共通イベント ─────────────────────────────────────

function bindCardEvents(videoId, type) {
  document.getElementById(`edit-btn-${videoId}`).addEventListener("click", () =>
    toggleEdit(videoId)
  );
  document.getElementById(`delete-btn-${videoId}`).addEventListener("click", () =>
    deleteItem(videoId, type)
  );
  document.getElementById(`save-btn-${videoId}`).addEventListener("click", () =>
    saveItem(videoId, type)
  );
  document.getElementById(`cancel-btn-${videoId}`).addEventListener("click", () =>
    toggleEdit(videoId, false)
  );
  // 動画カードのみ：音楽へ移動ボタン
  const moveBtn = document.getElementById(`move-btn-${videoId}`);
  if (moveBtn) {
    moveBtn.addEventListener("click", () => moveToMusic(videoId));
  }
}

function toggleEdit(videoId, open = null) {
  const form = document.getElementById(`edit-form-${videoId}`);
  form.classList.toggle("open", open !== null ? open : !form.classList.contains("open"));
}

async function moveToMusic(videoId) {
  if (!confirm("この動画を音楽タブに移動しますか？")) return;
  const result = await msg("MOVE_TO_SONGS", { videoId });
  if (result.success) {
    showToast("🎵 音楽タブに移動しました");
    await loadAll();
  } else {
    showToast("移動に失敗しました", true);
  }
}

async function saveItem(videoId, type) {
  const title = document.getElementById(`edit-title-${videoId}`).value.trim();
  if (!title) return;
  const payload = { videoId, title };
  const artistEl = document.getElementById(`edit-artist-${videoId}`);
  if (artistEl) payload.artist = artistEl.value.trim();
  const composerEl = document.getElementById(`edit-composer-${videoId}`);
  if (composerEl) payload.composer = composerEl.value.trim();

  const msgType = type === "song" ? "UPDATE_SONG" : "UPDATE_VIDEO";
  await msg(msgType, payload);
  showToast("保存しました ✓");
  await loadAll();
}

async function deleteItem(videoId, type) {
  if (!confirm("この記録を削除しますか？")) return;
  const msgType = type === "song" ? "DELETE_SONG" : "DELETE_VIDEO";
  await msg(msgType, { videoId });
  showToast("削除しました");
  await loadAll();
}

// ── ユーティリティ ─────────────────────────────────────────

function fmtDate(iso) {
  const d = new Date(iso);
  return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,"0")}/${String(d.getDate()).padStart(2,"0")}`;
}
function esc(str) {
  return (str||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function emptyState(icon, text) {
  return `<div class="empty-state"><div class="icon">${icon}</div><p>${text}</p></div>`;
}
function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2500);
}

init();
