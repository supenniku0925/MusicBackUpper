// timeline_common.js v10

function esc(str) {
  return (str || "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function fmtDate(iso) {
  const d = new Date(iso);
  return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,"0")}/${String(d.getDate()).padStart(2,"0")}`;
}
function thumbUrl(videoId) {
  return `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`;
}

// サマリーバーを描画
function renderSummary(items, stats) {
  document.getElementById("summaryBar").innerHTML = stats
    .map((s) => `<div class="summary-item">
      <span class="summary-value">${s.value}</span>
      <span class="summary-label">${s.label}</span>
    </div>`).join("");
}

// 初めて聴いた日タイムライン
function renderFirstTimeline(items, container, subHtml) {
  if (!items.length) { container.innerHTML = emptyState(); return; }
  const tree = buildTree(items, (x) => new Date(x.firstListened));
  container.innerHTML = Object.keys(tree).sort((a, b) => b - a).map((year) => {
    const months = tree[year];
    const yearTotal = Object.values(months).reduce((s, arr) => s + arr.length, 0);
    const monthsHtml = Object.keys(months).sort((a, b) => b - a).map((month) => {
      const arr = months[month].sort((a, b) => b.playCount - a.playCount);
      return monthSection(month, `${arr.length}件`, arr.map((x, i) => songRow(x, i + 1, fmtDate(x.firstListened), subHtml(x))));
    }).join("");
    return yearSection(year, `${yearTotal}件`, monthsHtml);
  }).join("");
}

// 再生回数タイムライン（年別回数 + 累計を表示）
function renderPlaysTimeline(items, container, subHtml) {
  if (!items.length) { container.innerHTML = emptyState(); return; }

  // 各アイテムの playsByYear を使って年ごとにグループ化
  // 「その年に1回以上聴いた曲」をその年に表示する
  const tree = {}; // { year: [{ item, yearCount }] }
  items.forEach((x) => {
    const playsByYear = x.playsByYear || {};
    // playsByYear がない場合は lastPlayed の年にフォールバック
    const years = Object.keys(playsByYear).length > 0
      ? Object.keys(playsByYear)
      : [new Date(x.lastPlayed || x.firstListened).getFullYear().toString()];

    years.forEach((year) => {
      if (!tree[year]) tree[year] = [];
      tree[year].push({ item: x, yearCount: playsByYear[year] || 0 });
    });
  });

  container.innerHTML = Object.keys(tree).sort((a, b) => b - a).map((year) => {
    const entries = tree[year].sort((a, b) => b.yearCount - a.yearCount);
    const yearTotalPlays = entries.reduce((s, e) => s + e.yearCount, 0);

    const rows = entries.map((e, i) => {
      const x = e.item;
      return `
        <a class="song-row" href="${x.url}" target="_blank">
          <img class="song-thumb" src="${thumbUrl(x.videoId)}" alt="" loading="lazy" />
          <span class="song-rank">#${i + 1}</span>
          <div class="song-info">
            <div class="song-title-text">${esc(x.title)}</div>
            ${subHtml(x)}
          </div>
          <div class="song-stats">
            <span class="play-count">▶ 累計 ${x.playCount}回</span>
            <span class="first-date">${year}年: ${e.yearCount}回</span>
          </div>
        </a>`;
    });

    return `
      <div class="year-section">
        <div class="year-header">
          <div class="year-badge">${year}</div>
          <span class="year-count">この年に ${yearTotalPlays}回再生</span>
          <div class="year-line"></div>
        </div>
        <div class="song-grid">${rows.join("")}</div>
      </div>`;
  }).join("");
}

// ── カレンダービュー ─────────────────────────────────────

let _calItems = [];
let _calSubHtml = null;
let _calYear = new Date().getFullYear();
let _calMonth = new Date().getMonth(); // 0-indexed

function renderCalendarView(items, container, subHtml) {
  _calItems = items;
  _calSubHtml = subHtml;
  if (!items.length) { container.innerHTML = emptyState(); return; }
  // 最新月を初期表示
  const dates = items.map((x) => new Date(x.firstListened));
  const latest = new Date(Math.max(...dates));
  _calYear = latest.getFullYear();
  _calMonth = latest.getMonth();
  drawCalendar(container);
}

function drawCalendar(container) {
  const today = new Date();
  const year = _calYear;
  const month = _calMonth; // 0-indexed

  // その月のアイテムを日付でグループ化
  const byDay = {};
  _calItems.forEach((x) => {
    const d = new Date(x.firstListened);
    if (d.getFullYear() === year && d.getMonth() === month) {
      const day = d.getDate();
      if (!byDay[day]) byDay[day] = [];
      byDay[day].push(x);
    }
  });
  // 各日付内を再生回数順にソート
  Object.keys(byDay).forEach((day) => {
    byDay[day].sort((a, b) => b.playCount - a.playCount);
  });

  const firstDay = new Date(year, month, 1).getDay(); // 0=Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const monthNames = ["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"];
  const dows = ["日","月","火","水","木","金","土"];

  let html = `
    <div class="calendar-nav">
      <button class="calendar-nav-btn" id="calPrev">◀</button>
      <div class="calendar-nav-title">${year}年 ${monthNames[month]}</div>
      <button class="calendar-nav-btn" id="calNext">▶</button>
    </div>
    <div class="calendar-grid">
      ${dows.map((d) => `<div class="calendar-dow">${d}</div>`).join("")}
  `;

  // 空白セル
  for (let i = 0; i < firstDay; i++) {
    html += `<div class="calendar-cell empty"></div>`;
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;
    const items = byDay[day] || [];
    const hasItems = items.length > 0;
    const MAX_SHOW = 2;

    let cellContent = `<div class="cell-date">${day}</div>`;

    if (hasItems) {
      const showItems = items.slice(0, MAX_SHOW);
      cellContent += showItems.map((x) => `
        <a href="${x.url}" target="_blank" style="display:block;text-decoration:none;" onclick="event.stopPropagation()">
          <img class="cell-thumb-img" src="${thumbUrl(x.videoId)}" alt="" loading="lazy" />
          <div class="cell-thumb-title">${esc(x.title)}</div>
        </a>`).join("");
      if (items.length > MAX_SHOW) {
        cellContent += `<div class="cell-more">+${items.length - MAX_SHOW}件</div>`;
      }
    }

    html += `<div class="calendar-cell ${isToday ? "today" : ""} ${hasItems ? "has-items" : ""}"
      data-day="${day}">${cellContent}</div>`;
  }

  html += `</div>`;
  container.innerHTML = html;

  // ナビゲーション
  container.querySelector("#calPrev").addEventListener("click", () => {
    _calMonth--;
    if (_calMonth < 0) { _calMonth = 11; _calYear--; }
    drawCalendar(container);
  });
  container.querySelector("#calNext").addEventListener("click", () => {
    _calMonth++;
    if (_calMonth > 11) { _calMonth = 0; _calYear++; }
    drawCalendar(container);
  });

  // セルクリックでモーダル
  container.querySelectorAll(".calendar-cell.has-items").forEach((cell) => {
    cell.addEventListener("click", (e) => {
      if (e.target.tagName === "A" || e.target.closest("a")) return;
      const day = parseInt(cell.dataset.day);
      showCalModal(byDay[day] || [], year, month, day);
    });
  });
}

function showCalModal(items, year, month, day) {
  const overlay = document.createElement("div");
  overlay.className = "cal-modal-overlay";
  const monthNames = ["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"];
  overlay.innerHTML = `
    <div class="cal-modal">
      <div class="cal-modal-title">
        <button class="cal-modal-close" id="modalClose">✕</button>
        ${year}年${monthNames[month]}${day}日
      </div>
      <div class="song-grid">
        ${items.map((x) => `
          <a class="song-row" href="${x.url}" target="_blank">
            <img class="song-thumb" src="${thumbUrl(x.videoId)}" alt="" loading="lazy" />
            <div class="song-info">
              <div class="song-title-text">${esc(x.title)}</div>
              ${_calSubHtml ? _calSubHtml(x) : ""}
            </div>
            <div class="song-stats">
              <span class="play-count">▶ ${x.playCount}回</span>
            </div>
          </a>`).join("")}
      </div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector("#modalClose").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

// ── ビルダー関数 ─────────────────────────────────────────

function buildTree(items, dateFn) {
  const tree = {};
  items.forEach((x) => {
    const d = dateFn(x);
    const y = d.getFullYear();
    const m = d.getMonth() + 1;
    if (!tree[y]) tree[y] = {};
    if (!tree[y][m]) tree[y][m] = [];
    tree[y][m].push(x);
  });
  return tree;
}

function yearSection(year, countText, monthsHtml) {
  return `
    <div class="year-section">
      <div class="year-header">
        <div class="year-badge">${year}</div>
        <span class="year-count">${countText}</span>
        <div class="year-line"></div>
      </div>
      ${monthsHtml}
    </div>`;
}

function monthSection(month, countText, rowsHtml) {
  return `
    <div class="month-section">
      <div class="month-header">
        <div class="month-dot"></div>
        <span class="month-label">${month}月</span>
        <span class="month-count">${countText}</span>
      </div>
      <div class="song-grid">${rowsHtml.join("")}</div>
    </div>`;
}

function songRow(x, rank, dateLine, extraHtml) {
  return `
    <a class="song-row" href="${x.url}" target="_blank">
      <img class="song-thumb" src="${thumbUrl(x.videoId)}" alt="" loading="lazy" />
      <span class="song-rank">${rank}</span>
      <div class="song-info">
        <div class="song-title-text">${esc(x.title)}</div>
        ${extraHtml}
      </div>
      <div class="song-stats">
        <span class="play-count">▶ ${x.playCount}回</span>
        <span class="first-date">${dateLine}</span>
      </div>
    </a>`;
}

function emptyState() {
  return `<div class="empty-timeline">
    <div class="icon">📭</div>
    <h2>まだ記録がありません</h2>
    <p>YouTubeで30秒以上視聴すると記録されます</p>
  </div>`;
}

// タブ切り替え初期化
function initTabs() {
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`tab-${btn.dataset.tab}`).classList.add("active");
    });
  });
}
