const GENRES = [
  { key:"gaming",       label:"ゲーム",         icon:"🎮" },
  { key:"education",    label:"教育",           icon:"📚" },
  { key:"entertainment",label:"エンタメ",       icon:"🎭" },
  { key:"howto",        label:"ハウツー",        icon:"💡" },
  { key:"science",      label:"科学・テクノロジー",icon:"🔬"},
  { key:"sports",       label:"スポーツ",        icon:"⚽" },
  { key:"news",         label:"ニュース",        icon:"📰" },
  { key:"vlog",         label:"ブログ・日常",    icon:"📝" },
  { key:"comedy",       label:"コメディ",        icon:"😂" },
  { key:"film",         label:"映画・アニメ",    icon:"🎬" },
  { key:"travel",       label:"旅行",            icon:"✈️" },
  { key:"other",        label:"その他",          icon:"📹" },
];

let selectedGenres = new Set();

function msg(type, payload) {
  return new Promise((res) => chrome.runtime.sendMessage({ type, payload }, res));
}

function renderGenreGrid() {
  document.getElementById("genreGrid").innerHTML = GENRES.map((g) => `
    <div class="genre-toggle ${selectedGenres.has(g.key) ? "active" : ""}" data-key="${g.key}">
      <div class="g-icon">${g.icon}</div>
      <div class="g-name">${g.label}</div>
      <div class="g-check">✓</div>
    </div>`).join("");

  document.querySelectorAll(".genre-toggle").forEach((el) => {
    el.addEventListener("click", () => {
      const k = el.dataset.key;
      selectedGenres.has(k) ? selectedGenres.delete(k) : selectedGenres.add(k);
      renderGenreGrid();
    });
  });
}

function updateApiStatusUI(hasKey) {
  const dot = document.getElementById("statusDot");
  const msg2 = document.getElementById("statusMsg");
  const txt = document.getElementById("apiStatusText");
  if (hasKey) {
    dot.className = "status-dot ok";
    msg2.textContent = "APIキーが設定されています";
    msg2.style.color = "#22c55e";
    txt.textContent = "設定済み ✓"; txt.style.color = "#22c55e";
  } else {
    dot.className = "status-dot none";
    msg2.textContent = "未設定（キーワード判定で動作中）";
    msg2.style.color = "#5a5a7a";
    txt.textContent = "未設定"; txt.style.color = "#5a5a7a";
  }
}

let customChannels = [];

function renderChannelTags() {
  const container = document.getElementById("channelTagList");
  if (customChannels.length === 0) {
    container.innerHTML = `<span style="font-size:12px;color:#4a4a6a;">登録されているチャンネルはありません</span>`;
    return;
  }
  container.innerHTML = customChannels.map((ch, i) => `
    <span style="display:inline-flex;align-items:center;gap:6px;
      background:#2a1a4a;border:1px solid #7c3aed44;
      border-radius:20px;padding:4px 12px;font-size:12px;color:#c084fc;">
      🎤 ${ch}
      <button data-i="${i}" style="background:none;border:none;color:#6b6b8a;
        cursor:pointer;font-size:14px;line-height:1;padding:0;">✕</button>
    </span>`).join("");

  container.querySelectorAll("button[data-i]").forEach((btn) => {
    btn.addEventListener("click", () => {
      customChannels.splice(parseInt(btn.dataset.i), 1);
      renderChannelTags();
    });
  });
}

function addChannel() {
  const input = document.getElementById("channelInput");
  const val = input.value.trim();
  if (!val) return;
  if (customChannels.includes(val)) {
    showToast("すでに登録されています", true);
    return;
  }
  customChannels.push(val);
  input.value = "";
  renderChannelTags();
}

// ── エクスポート・インポート ──────────────────────────────

async function exportData() {
  const data = await new Promise((res) =>
    chrome.storage.local.get(["songs", "videos", "manualMusicIds"], res)
  );

  const exportObj = {
    version: "1.0",
    exportedAt: new Date().toISOString(),
    songs: data.songs || {},
    videos: data.videos || {},
    manualMusicIds: data.manualMusicIds || [],
  };

  const json = JSON.stringify(exportObj, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const date = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `MusicBackUpper_backup_${date}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("エクスポートしました ✓");
}

async function importData(file) {
  try {
    const text = await file.text();
    const obj = JSON.parse(text);

    // バリデーション
    if (!obj.songs && !obj.videos) {
      showToast("無効なファイルです", true);
      return;
    }

    if (!confirm(
      `インポートしますか？\n` +
      `音楽: ${Object.keys(obj.songs || {}).length}曲\n` +
      `動画: ${Object.keys(obj.videos || {}).length}件\n\n` +
      `※ 既存データは上書きされます`
    )) return;

    await chrome.storage.local.set({
      songs: obj.songs || {},
      videos: obj.videos || {},
      manualMusicIds: obj.manualMusicIds || [],
    });

    showToast(`インポート完了 ✓（音楽${Object.keys(obj.songs || {}).length}曲・動画${Object.keys(obj.videos || {}).length}件）`);
  } catch (e) {
    showToast("インポート失敗: " + e.message, true);
  }
}

async function init() {
  const settings = await msg("GET_SETTINGS");
  selectedGenres = new Set(settings.enabledVideoGenres || []);
  customChannels = settings.customMusicChannels || [];
  renderGenreGrid();
  renderChannelTags();
  const key = settings.youtubeApiKey || "";
  document.getElementById("apiKeyInput").value = key;
  updateApiStatusUI(!!key);

  // エクスポート・インポート
  document.getElementById("btnExport").addEventListener("click", exportData);
  document.getElementById("btnImport").addEventListener("click", () => {
    document.getElementById("importFile").click();
  });
  document.getElementById("importFile").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) importData(file);
    e.target.value = ""; // 同じファイルを再選択できるようリセット
  });

  // チャンネル追加
  document.getElementById("btnAddChannel").addEventListener("click", addChannel);
  document.getElementById("channelInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); addChannel(); }
  });

  document.getElementById("btnSaveChannels").addEventListener("click", async () => {
    const s = await msg("GET_SETTINGS");
    await msg("SAVE_SETTINGS", { ...s, customMusicChannels: customChannels });
    showToast("チャンネルリストを保存しました ✓");
  });

  document.getElementById("btnSaveGenres").addEventListener("click", async () => {
    const s = await msg("GET_SETTINGS");
    await msg("SAVE_SETTINGS", { ...s, enabledVideoGenres: [...selectedGenres] });
    showToast("ジャンル設定を保存しました ✓");
  });

  document.getElementById("btnSelectAll").addEventListener("click", () => {
    selectedGenres = new Set(GENRES.map((g) => g.key));
    renderGenreGrid();
  });
  document.getElementById("btnDeselectAll").addEventListener("click", () => {
    selectedGenres.clear();
    renderGenreGrid();
  });

  document.getElementById("toggleVis").addEventListener("click", () => {
    const i = document.getElementById("apiKeyInput");
    i.type = i.type === "password" ? "text" : "password";
  });

  document.getElementById("btnSaveApi").addEventListener("click", async () => {
    const key = document.getElementById("apiKeyInput").value.trim();
    const s = await msg("GET_SETTINGS");
    await msg("SAVE_SETTINGS", { ...s, youtubeApiKey: key });
    updateApiStatusUI(!!key);
    showToast("APIキーを保存しました ✓");
  });

  document.getElementById("btnClearApi").addEventListener("click", async () => {
    if (!confirm("APIキーを削除しますか？")) return;
    document.getElementById("apiKeyInput").value = "";
    const s = await msg("GET_SETTINGS");
    await msg("SAVE_SETTINGS", { ...s, youtubeApiKey: "" });
    updateApiStatusUI(false);
    showToast("APIキーを削除しました");
  });

  document.getElementById("btnTest").addEventListener("click", async () => {
    const key = document.getElementById("apiKeyInput").value.trim();
    if (!key) { showToast("APIキーを入力してください", true); return; }
    showToast("テスト中...");
    const result = await msg("TEST_API_KEY", { apiKey: key });
    if (result.ok) {
      document.getElementById("statusDot").className = "status-dot ok";
      showToast("✓ " + result.message);
    } else {
      document.getElementById("statusDot").className = "status-dot err";
      showToast("✗ " + result.message, true);
    }
  });
}

function showToast(text, isErr = false) {
  const t = document.getElementById("toast");
  t.textContent = text;
  t.className = "toast show" + (isErr ? " err" : "");
  setTimeout(() => t.className = "toast", 3000);
}

init();
