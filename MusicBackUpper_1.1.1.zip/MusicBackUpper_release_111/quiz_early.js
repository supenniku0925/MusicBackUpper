// quiz_early.js v1.0.2 - タイトル書き換え＋映像黒幕CSS

(function () {
  const QUIZ_TITLE = "🎵 ♪♪♪";

  chrome.storage.local.get("quizModeTab", (data) => {
    const tabId = data.quizModeTab;
    if (!tabId) return;

    chrome.runtime.sendMessage({ type: "GET_CURRENT_TAB_ID" }, (myTabId) => {
      if (myTabId !== tabId) return;

      // タイトル即時書き換え
      document.title = QUIZ_TITLE;

      // CSS注入（タイトル非表示 + 動画映像を黒幕で隠す）
      const style = document.createElement("style");
      style.textContent = `
        title { display: none !important; }

        /* 動画プレイヤーを黒幕で覆う */
        #movie_player video,
        .html5-video-player video,
        video.video-stream {
          opacity: 0 !important;
          visibility: hidden !important;
        }

        /* プレイヤー全体に黒背景 */
        #movie_player,
        .html5-video-player {
          background: #000 !important;
        }
      `;
      document.documentElement.appendChild(style);

      // MutationObserverでtitleタグの変化を即捕捉
      const obs = new MutationObserver(() => {
        if (document.title !== QUIZ_TITLE) {
          document.title = QUIZ_TITLE;
        }
      });

      obs.observe(document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
      });

      // DOMContentLoaded後にtitleタグ直接監視に切り替え
      document.addEventListener("DOMContentLoaded", () => {
        document.title = QUIZ_TITLE;
        const titleEl = document.querySelector("title");
        if (titleEl) {
          obs.disconnect();
          const obs2 = new MutationObserver(() => {
            if (document.title !== QUIZ_TITLE) {
              document.title = QUIZ_TITLE;
            }
          });
          obs2.observe(titleEl, { childList: true, characterData: true, subtree: true });
        }
      });
    });
  });
})();
